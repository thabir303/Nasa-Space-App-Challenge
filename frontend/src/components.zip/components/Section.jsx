import React from 'react';
import './Section.css';

const Section = ({ title, image, description }) => {
  return (
    <div className="section">
      <h2>{title}</h2>
      <img src={image} alt={title} className="section-image" />
      <p>{description}</p>
    </div>
  );
};

export default Section;
